
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuItem
    , DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { ColumnDef } from "@tanstack/react-table"
import { NotebookTabs, UserPen, Wrench } from "lucide-react";

// This type is used to define the shape of our data.
// You can use a Zod schema here if you want.
export type Profesor = {
    id: number;
    nombre: string;
    email: string;
    fecha_creacion: Date;
    cedula: string;
    telefono: string;
    direccion: string;
    rol: string;
    estado: string;
};

export const columns: ColumnDef<Profesor>[] = [
    {
        accessorKey: "id",
        header: "Id",

    },
    {
        accessorKey: "cedula",
        header: "Cedula",
    },
    {
        accessorKey: "nombre",
        header: "Nombres",
    },
    {
        accessorKey: "estado",
        header: "Estado",
    },
    {
        accessorKey: "email",
        header: "Email",
    },
    { accessorKey: "telefono", header: "Telefono" },
    { accessorKey: "direccion", header: "Direccion" },
    { accessorKey: "rol", header: "Rol" },
    {
        accessorKey: "fecha_creacion",
        header: "Fecha de Creacion",

    },
    {
        id: "Acciones",
        enableHiding: true,
        cell: ({ row }) => {
            return (
                <DropdownMenu >
                    <DropdownMenuTrigger >
                        <Wrench color="#22c55e" />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent
                        className="w-56 p-2 shadow-md bg-background rounded-box"
                    >
                        <DropdownMenuLabel>Acciones</DropdownMenuLabel>
                        <DropdownMenuItem
                        // onClick={() => navigator.clipboard.writeText(payment.id)}
                        >
                            <UserPen  />Editar
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem> <NotebookTabs  /> Ver Planificaciones</DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            )

        },
    }
]